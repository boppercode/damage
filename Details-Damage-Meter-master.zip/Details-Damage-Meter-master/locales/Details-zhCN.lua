local L = LibStub("AceLocale-3.0"):NewLocale("Details", "zhCN") 
if not L then return end 

@localization(locale="zhCN", format="lua_additive_table")@