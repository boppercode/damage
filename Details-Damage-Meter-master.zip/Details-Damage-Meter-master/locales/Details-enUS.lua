local L = LibStub("AceLocale-3.0"):NewLocale ("Details", "enUS", true) 
if not L then return end 

--------------------------------------------------------------------------------------------------------------------------------------------

@localization(locale="enUS", format="lua_additive_table")@